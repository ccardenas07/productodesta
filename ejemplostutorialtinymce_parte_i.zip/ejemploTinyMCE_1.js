function cargarTinyMCE()
{
	tinyMCE.init({
		mode : "textareas",
		theme : "simple"
	});
  }